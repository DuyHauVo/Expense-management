import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
    apiKey: "AIzaSyBs5AO5_ZR1OwmmPHKBQ2iYV9aLKsONBUw",
    authDomain: "expense-management-d41f0.firebaseapp.com",
    projectId: "expense-management-d41f0",
    storageBucket: "expense-management-d41f0.appspot.com",
    messagingSenderId: "527520813892",
    appId: "1:527520813892:web:d2454bb8aa9b90420afd11",
    measurementId: "G-PV9PCD4VG1"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
export const storage = getStorage(app);