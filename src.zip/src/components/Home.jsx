import React, { useEffect, useState } from "react";
import axios from "axios";

function Home(props) {
  const [categories, setCategories] = useState([]);
  const [check,setCheck] = useState("chi");
  useEffect(() => {
    fetchCategories();
  }, []);

  const fetchCategories = async () => {
    try {
      const response = await axios.get(
        "https://669b0830276e45187d347a83.mockapi.io/todos"
      );
      setCategories(response.data);
    } catch (error) {
      console.error("Error fetching categories:", error);
    }
  };

  return (
    <div>
      <h1 className="text-center">
        <button onClick={() => setCheck("chi")} type="button" class={`btn text-white ${check == "chi" ? "btn-warning" : "btn-secondary" }`}>
          Tiền chi
        </button>
        <button onClick={() => setCheck("thu")} type="button" class={`btn ms-2 text-white ${check == "thu" ? "btn-warning" : "btn-secondary" }`}>
          Tiền thu
        </button>
      </h1>
      <form>
        <div className="form-text w-50 m-auto">
          <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">
              Date
            </label>
            <input type="Date" class="form-control" />
          </div>
          <div class="mb-3">
            <label for="exampleInputPassword1" class="form-label">
              Note
            </label>
            <input type="text" class="form-control" />
          </div>
          <div class="mb-3">
            <label for="exampleInputPassword1" class="form-label">
              Price
            </label>
            <input type="number" class="form-control" min={0} placeholder="0" />
          </div>
        </div>
        <div className="form-categories container">
          <div className="text-center">
            <label
              className="mb-4"
              for="exampleInputPassword1"
              class="form-label"
            >
              Categories
            </label>
          </div>
          <div className="row row-cols-lg-4 row-cols-md-2 row-cols-1 g-3">
            {categories.filter(element => element.check == check).map((element) => (
              <div className="col">
                <div class="card p-3">
                  <div className="card-img w-50 m-auto ">
                    <img src={element.img} class="card-img-top" alt="..." />
                  </div>
                  <div class="card-body">
                    <p class="card-text text-center">{element.title}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className="text-center mt-5">
          <button type="submit" class="btn btn-primary">
            Submit
          </button>
        </div>
      </form>
    </div>
  );
}

export default Home;
