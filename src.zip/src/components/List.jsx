import React from "react";

function List(props) {
  return (
    <div>
      <h1>Form List</h1>
    </div>
  );
}

export default List;
