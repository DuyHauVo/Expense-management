import React, { useEffect, useState } from "react";
import { storage } from "../config/firebase";
import {
  ref,
  uploadBytes,
  getDownloadURL,
  deleteObject,
} from "firebase/storage";
import { v4 as uuidv4 } from "uuid";
import axios from "axios";
function Categories(props) {
  const [imgUpload, setImgUpload] = useState(null);
  const [previewImg, setPreviewImg] = useState(null);

  // Handle img Change
  const handleImageChange = (e) => {
    const selectedImg = e.target.files[0];

    if (selectedImg) {
      const reader = new FileReader();
      reader.onload = () => {
        setPreviewImg(reader.result);
      };
      reader.readAsDataURL(selectedImg);
      setImgUpload(selectedImg);
    } else {
      setPreviewImg(null);
      setImgUpload(null);
    }
  };

  const submitAddCategory = async (event) => {
    event.preventDefault();

    const formData = new FormData(event.target);
    const title = formData.get("title");
    const check = formData.get('spending-item');

    // Upload product image to storage
    const categoryImgRef = ref(storage, `categories/${uuidv4()}`);
    await uploadBytes(categoryImgRef, imgUpload);

    // Get download URL for the product image
    const categoryImgURL = await getDownloadURL(categoryImgRef);

    const category = {
      title: title,
      img: categoryImgURL,
      check : check
    };
    console.log(category);
    await axios.post(
      "https://669b0830276e45187d347a83.mockapi.io/todos",
      category
    );
    alert("Add categories success !");
  };

  return (
    <div>
      <form
        onSubmit={submitAddCategory}
        className="w-50 m-auto mt-5 form-add-category p-3 "
      >
        <h1 className="text-center">ADD CATEGORY</h1>
        <div class="mb-3">
          <div className="form-img w-25 m-auto">
            <img
              src={
                previewImg
                  ? previewImg
                  : "https://cdn-icons-png.flaticon.com/512/17282/17282300.png"
              }
              alt=""
            />
          </div>
          <input
            type="file"
            onChange={handleImageChange}
            class="form-control mt-3"
          />
        </div>
        <div class="mb-3">
          <label class="form-label">Title</label>
          <input type="text" class="form-control" name="title" />
        </div>
        <div className="mb-3 d-flex">
          <div class="form-check">
            <input
              class="form-check-input"
              type="radio"
              name="spending-item"
              value="chi"
            />
            <label class="form-check-label" for="flexRadioDefault1">
              Mục Chi
            </label>
          </div>
          <div class="form-check ms-3">
            <input
              class="form-check-input"
              type="radio"
              name="spending-item"
              value="thu"
            />
            <label class="form-check-label" for="flexRadioDefault1">
              Mục Thu
            </label>
          </div>
        </div>

        <div className="text-center">
          <button type="submit" class="btn btn-success">
            Add Category
          </button>
        </div>
      </form>
    </div>
  );
}

export default Categories;
